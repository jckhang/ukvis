offsets = {};

offsets['West Ruislip'] = { x: 349, y:1652, friendly: "West Ruislip" };