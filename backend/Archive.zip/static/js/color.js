var lineColor = {
	"Bakerloo": "#a45a2a",
	"Central": "#da291c",
	"Circle": "#ffcd00",
	"District": "#007a33",
	"Hammersmith & City": "#e89cae",
	"Jubilee": "#7c878e",
	"Metropolitan":"#840b55",
	"Northern": "#000000",
	"Piccadilly": "#10069f",
	"Victoria": "#00a3e0",
	"Waterloo & City": "#6eceb2",
	"Overground":"#e87722",
	"TFL Rail":"#10069f",
	"DLR":"#00b2a9"
}